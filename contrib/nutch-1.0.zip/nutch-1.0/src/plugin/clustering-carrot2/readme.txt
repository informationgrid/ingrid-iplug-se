This plugin extension adds search results clustering capability to Nutch search 
frontend.

Carrot2 JARs come from codebase in version: 2.1

See the WIKI for more information about configuration and installation
of this plugin.
