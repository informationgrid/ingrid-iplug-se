Pugin to support parsing of MS PowerPoint files.

Contributed by Stephan Strittmatter <Stephan.Strittmatter@sybit.de>. 

Note:
======
For parsing MS PowerPoint files it is required to get the complete filestream.
Please check the property <protocol>.content.limit at nutch-default.xml.