Directory to store PowerPoint samples.
If ther is a file "test.ppt" the testcase searches for a reference file "test.ppt.content"
to compare the extracted content.
Additionaly a file "test.ppt.meta" could be stored here to compair the meta information.

-- Stephan Strittmatter
