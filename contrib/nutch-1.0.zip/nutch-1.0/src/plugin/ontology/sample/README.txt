20041129, John Xing

time.owl is very simple owl file used for junit testing of ontology plugin.
It has Class "Season" and its 4 subclasses:
"Spring", "Summer", "Fall" and "Winter"
