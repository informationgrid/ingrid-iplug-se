* create conf/nutch-site.xml
* create conf/regex-urlfilter.txt

start the AdministrationApp

